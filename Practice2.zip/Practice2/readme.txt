Aki changed this file.
conflict change!
Change
Hellooooooooo
rebase practice.
you enter continue command when happen conflict.
another change by April
new April change
continue Test hogefugahoge
continue Test!!!!!!
Exclamation mark added same line
Kyrie Test
Conflict Test by April
My First Test!!!
Conflict Test By Kyrie!
Added for multiple conflict!!
I add another txt on my account!
Hope it succeed!
Just trying it at home
As of 3-6-14 Added by April
Ill try the other branch
Conflict of interest.
This is April